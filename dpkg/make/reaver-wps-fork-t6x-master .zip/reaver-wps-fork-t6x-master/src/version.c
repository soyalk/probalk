#include "version.h"

const char* get_version(void) {
	return R_VERSION;
}
